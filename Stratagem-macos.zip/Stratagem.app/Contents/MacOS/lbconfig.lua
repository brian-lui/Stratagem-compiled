return {
	name = 'Stratagem',
	config = '',
	platform = 'macos',
	version = '1.0.0',
	love = '11.5'
}