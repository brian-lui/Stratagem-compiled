return {
	name = 'Stratagem',
	config = '',
	platform = 'win64',
	version = '1.0.0',
	love = '11.5'
}